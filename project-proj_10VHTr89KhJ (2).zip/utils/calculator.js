function calculateBottleneck(cpu, gpu, ram, resolution) {
    try {
        if (!cpu || !gpu || !ram || !resolution) {
            return null;
        }

        const cpuScore = parseInt(cpu);
        const gpuScore = parseInt(gpu);
        const ramScore = parseInt(ram);
        const resolutionScore = parseInt(resolution);

        let bottleneckPercentage = 0;
        let description = '';
        const recommendations = [];
        const upgradePath = [];
        const optimizations = [];

        // Calculate CPU-GPU balance
        const cpuGpuRatio = cpuScore / gpuScore;
        if (cpuGpuRatio < 0.8) {
            bottleneckPercentage += 15;
            recommendations.push("Your CPU is significantly weaker than your GPU, causing a bottleneck");
            
            // CPU upgrade suggestions based on GPU
            if (gpuScore >= 90) {
                upgradePath.push({
                    component: "CPU",
                    suggestion: "Consider upgrading to Intel Core i9 or AMD Ryzen 9",
                    examples: ["Intel Core i9-13900K", "AMD Ryzen 9 7950X"],
                    priority: "High"
                });
            } else if (gpuScore >= 80) {
                upgradePath.push({
                    component: "CPU",
                    suggestion: "Consider upgrading to Intel Core i7 or AMD Ryzen 7",
                    examples: ["Intel Core i7-13700K", "AMD Ryzen 7 7700X"],
                    priority: "High"
                });
            }

            optimizations.push(
                "Lower CPU-intensive settings like physics, AI, and NPC density in games",
                "Close background applications to free up CPU resources",
                "Enable hardware-accelerated GPU scheduling in Windows"
            );
        } else if (cpuGpuRatio > 1.2) {
            bottleneckPercentage += 10;
            recommendations.push("Your CPU is more powerful than necessary for your GPU");
            
            // GPU upgrade suggestions based on CPU
            if (cpuScore >= 90) {
                upgradePath.push({
                    component: "GPU",
                    suggestion: "Consider upgrading to a high-end GPU",
                    examples: ["NVIDIA RTX 4080", "AMD RX 7900 XT"],
                    priority: "Medium"
                });
            } else if (cpuScore >= 80) {
                upgradePath.push({
                    component: "GPU",
                    suggestion: "Consider upgrading to a mid-to-high-end GPU",
                    examples: ["NVIDIA RTX 4070", "AMD RX 7700 XT"],
                    priority: "Medium"
                });
            }

            optimizations.push(
                "Increase graphics quality settings to utilize your CPU better",
                "Enable Ray Tracing if available",
                "Use GPU-intensive post-processing effects"
            );
        }

        // RAM Analysis
        if (ramScore < 8) {
            bottleneckPercentage += 20;
            recommendations.push("Insufficient RAM for modern computing and gaming");
            upgradePath.push({
                component: "RAM",
                suggestion: "Upgrade to at least 16GB DDR4/DDR5 RAM",
                examples: ["16GB (2x8GB) DDR4-3600", "32GB (2x16GB) DDR5-5200"],
                priority: "Critical"
            });
            optimizations.push(
                "Close unnecessary background applications",
                "Disable startup programs",
                "Monitor memory usage with Task Manager"
            );
        } else if (ramScore < 16) {
            bottleneckPercentage += 10;
            recommendations.push("RAM might be insufficient for some modern games and applications");
            upgradePath.push({
                component: "RAM",
                suggestion: "Consider upgrading to 32GB for future-proofing",
                examples: ["32GB (2x16GB) DDR4-3600", "32GB (2x16GB) DDR5-5200"],
                priority: "Medium"
            });
        }

        // Resolution Impact
        if (resolutionScore > gpuScore * 0.8) {
            bottleneckPercentage += 10;
            recommendations.push("Your GPU might struggle with this resolution");
            
            if (resolutionScore === 100) { // 4K
                upgradePath.push({
                    component: "GPU",
                    suggestion: "Upgrade GPU for 4K gaming",
                    examples: ["NVIDIA RTX 4080", "AMD RX 7900 XTX"],
                    priority: "High"
                });
                optimizations.push(
                    "Use DLSS or FSR if available",
                    "Lower demanding graphics settings",
                    "Consider gaming at 1440p for better performance"
                );
            } else if (resolutionScore === 80) { // 1440p
                upgradePath.push({
                    component: "GPU",
                    suggestion: "Upgrade GPU for 1440p gaming",
                    examples: ["NVIDIA RTX 4070", "AMD RX 7700 XT"],
                    priority: "Medium"
                });
                optimizations.push(
                    "Use DLSS or FSR if available",
                    "Optimize graphics settings",
                    "Consider adaptive sync technology"
                );
            }
        }

        // Generate overall description
        if (bottleneckPercentage >= 20) {
            description = "Significant bottleneck detected. Your components are not well balanced, which may result in suboptimal performance.";
        } else if (bottleneckPercentage >= 10) {
            description = "Moderate bottleneck present. While your system will work, there's room for improvement.";
        } else {
            description = "Your system is well balanced. All components work together efficiently.";
        }

        return {
            percentage: bottleneckPercentage,
            description,
            recommendations,
            upgradePath,
            optimizations
        };
    } catch (error) {
        reportError(error);
        return null;
    }
}
