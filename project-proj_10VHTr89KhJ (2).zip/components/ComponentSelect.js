function ComponentSelect({ label, options, value, onChange }) {
    try {
        return (
            <div className="mb-4" data-name="component-select">
                <label className="block text-gray-700 text-sm font-bold mb-2" data-name="component-label">
                    {label}
                </label>
                <select
                    className="w-full p-2 border rounded component-card"
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    data-name="component-dropdown"
                >
                    <option value="">Select {label}</option>
                    {options.map((option) => (
                        <option key={option.value} value={option.value} data-name="component-option">
                            {option.label}
                        </option>
                    ))}
                </select>
            </div>
        );
    } catch (error) {
        reportError(error);
        return null;
    }
}
