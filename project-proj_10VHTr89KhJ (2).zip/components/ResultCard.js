function ResultCard({ bottleneck }) {
    try {
        if (!bottleneck) return null;

        const getBottleneckClass = (percentage) => {
            if (percentage >= 20) return 'bottleneck-severe';
            if (percentage >= 10) return 'bottleneck-moderate';
            return 'bottleneck-mild';
        };

        const getProgressBarClass = (percentage) => {
            if (percentage >= 20) return 'progress-bar-severe';
            if (percentage >= 10) return 'progress-bar-moderate';
            return 'progress-bar-mild';
        };

        const getRecommendationClass = (percentage) => {
            if (percentage >= 20) return 'recommendation-severe';
            if (percentage >= 10) return 'recommendation-moderate';
            return 'recommendation-mild';
        };

        const getPriorityIcon = (priority) => {
            switch (priority) {
                case 'Critical': return 'fa-exclamation-circle text-red-600';
                case 'High': return 'fa-arrow-up text-orange-500';
                case 'Medium': return 'fa-arrow-right text-yellow-500';
                default: return 'fa-info-circle text-blue-500';
            }
        };

        const getIcon = (percentage) => {
            if (percentage >= 20) return 'fa-triangle-exclamation';
            if (percentage >= 10) return 'fa-circle-exclamation';
            return 'fa-circle-check';
        };

        return (
            <div className="result-card p-6 mt-6" data-name="result-card">
                <div className="result-header" data-name="result-header">
                    <i className={`fas ${getIcon(bottleneck.percentage)} result-icon ${getBottleneckClass(bottleneck.percentage)}`}></i>
                    <div>
                        <h2 className="text-xl font-bold" data-name="result-title">Bottleneck Analysis</h2>
                        <p className={`text-lg ${getBottleneckClass(bottleneck.percentage)}`} data-name="bottleneck-percentage">
                            {bottleneck.percentage}% Bottleneck
                        </p>
                    </div>
                </div>

                <div className="progress-bar" data-name="bottleneck-progress">
                    <div 
                        className={`progress-bar-fill ${getProgressBarClass(bottleneck.percentage)}`}
                        style={{ width: `${Math.min(100, bottleneck.percentage * 2)}%` }}
                    ></div>
                </div>

                <div className="stats-grid" data-name="performance-stats">
                    <div className="stat-item">
                        <div className="stat-label">Performance Impact</div>
                        <div className="stat-value">
                            {bottleneck.percentage >= 20 ? 'High' : bottleneck.percentage >= 10 ? 'Medium' : 'Low'}
                        </div>
                    </div>
                    <div className="stat-item">
                        <div className="stat-label">System Balance</div>
                        <div className="stat-value">
                            {bottleneck.percentage < 10 ? 'Optimal' : 'Needs Improvement'}
                        </div>
                    </div>
                </div>

                <p className="text-gray-700 my-4" data-name="bottleneck-description">
                    {bottleneck.description}
                </p>

                {bottleneck.upgradePath.length > 0 && (
                    <div className="mt-6" data-name="upgrade-recommendations">
                        <h3 className="font-bold mb-2 text-lg">Recommended Upgrades:</h3>
                        <div className="space-y-4">
                            {bottleneck.upgradePath.map((upgrade, index) => (
                                <div key={index} className="bg-gray-50 rounded-lg p-4 border-l-4 border-blue-500" data-name="upgrade-item">
                                    <div className="flex items-center mb-2">
                                        <i className={`fas ${getPriorityIcon(upgrade.priority)} mr-2`}></i>
                                        <span className="font-bold">{upgrade.component} Upgrade - {upgrade.priority} Priority</span>
                                    </div>
                                    <p className="text-gray-700 mb-2">{upgrade.suggestion}</p>
                                    <div className="bg-gray-100 p-2 rounded">
                                        <span className="text-sm font-semibold">Recommended Products:</span>
                                        <ul className="list-disc ml-5 text-sm text-gray-600">
                                            {upgrade.examples.map((example, i) => (
                                                <li key={i}>{example}</li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {bottleneck.optimizations.length > 0 && (
                    <div className="mt-6" data-name="optimization-tips">
                        <h3 className="font-bold mb-2 text-lg">Immediate Optimization Tips:</h3>
                        <div className="bg-gray-50 rounded-lg p-4">
                            <ul className="space-y-2">
                                {bottleneck.optimizations.map((tip, index) => (
                                    <li key={index} className="flex items-start" data-name="optimization-item">
                                        <i className="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                                        <span>{tip}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                )}
            </div>
        );
    } catch (error) {
        reportError(error);
        return null;
    }
}
